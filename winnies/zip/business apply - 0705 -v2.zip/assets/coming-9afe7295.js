import{j as o}from"./index-dbc526dc.js";const r=()=>o.jsx("h1",{children:"coming soon..."});export{r as default};
