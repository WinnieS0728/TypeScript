import{j as o}from"./index-64ed6d48.js";const r=()=>o.jsx("h1",{children:"coming soon..."});export{r as default};
