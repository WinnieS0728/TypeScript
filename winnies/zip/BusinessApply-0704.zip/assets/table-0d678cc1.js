import{n as r,j as s}from"./index-093a3f53.js";const i=({className:e,title:a,children:n,filter:t})=>s.jsxs("div",{className:e,children:[a&&s.jsxs("div",{className:"header",children:[a,t]}),s.jsx("div",{className:"table-wrapper",children:n})]}),d=r(i)`
    .header{
        display: flex;
        justify-content: space-between;
        align-items: center;
        background-color: ${e=>e.theme.sectionHeader};
        color: ${e=>e.theme.white};
        padding: 0.5rem 1em;

        span{
            margin-inline: 0.5em;
        }
    }
    tbody{
        position: relative;
    }
`;export{d as s};
