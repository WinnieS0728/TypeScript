import{j as o}from"./index-093a3f53.js";const r=()=>o.jsx("h1",{children:"coming soon..."});export{r as default};
