import{j as o}from"./index-17ad10ea.js";const r=()=>o.jsx("h1",{children:"coming soon..."});export{r as default};
