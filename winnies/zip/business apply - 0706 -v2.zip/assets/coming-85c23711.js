import{j as o}from"./index-19d1e496.js";const r=()=>o.jsx("h1",{children:"coming soon..."});export{r as default};
