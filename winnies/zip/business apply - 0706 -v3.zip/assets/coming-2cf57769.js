import{j as o}from"./index-6033a868.js";const r=()=>o.jsx("h1",{children:"coming soon..."});export{r as default};
