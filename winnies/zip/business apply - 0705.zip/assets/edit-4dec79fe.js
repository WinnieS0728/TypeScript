import{n as o,u as n,j as e,N as a,H as r,O as c}from"./index-d5a76b80.js";const l=({className:t})=>{const{t:s}=n(["settingPage"]);return e.jsx(e.Fragment,{children:e.jsx("nav",{className:t,children:e.jsx("div",{className:"container-fluid",children:e.jsxs("ul",{className:"row p-2 gap-2 m-0",children:[e.jsx(a,{end:!0,to:"tx",className:"col-auto",children:s("nav.tx")}),e.jsx(a,{end:!0,to:"threshold",className:"col-auto",children:s("nav.threshold")}),e.jsx(a,{end:!0,to:"store",className:"col-auto",children:s("nav.store achieve")}),e.jsx(a,{end:!0,to:"osom",className:"col-auto",children:s("nav.osom achieve")})]})})})})},i=o(l)`
    background-color: ${t=>t.theme.navBgc};

    a {
        border: 1px solid ${t=>t.theme.white};
        color: ${t=>t.theme.white};
        border-radius: .5rem;
        padding: .2em .5em;

        &.active {
            background-color: ${t=>t.theme.navActive};
        }
    }
`,h=()=>{const{t}=n(["settingPage"]);return e.jsxs(e.Fragment,{children:[e.jsx(r,{title:t("title")}),e.jsx(i,{}),e.jsx(c,{})]})};export{h as default};
